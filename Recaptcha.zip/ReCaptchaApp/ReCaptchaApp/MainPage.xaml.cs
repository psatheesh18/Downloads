﻿using System;
using ReCaptchaApp.Services;
using Xamarin.Forms;
using Xamarin.Essentials;

namespace ReCaptchaApp
{
    public partial class MainPage : ContentPage
    {
        private static readonly string SiteKey = DeviceInfo.Platform == DevicePlatform.Android ? "6LfZue0gAAAAAJ0ki-HzE9spyf-9b5qsg9cMSpYU" : "6Lfbwe0gAAAAAK9TDA7zpwol5TKxwdHv14Igxm8n";
        private static readonly string SiteSecretKey = DeviceInfo.Platform == DevicePlatform.Android ? "6LfZue0gAAAAAD46Zj3INeeDQlhQLQkbPHcKcakZ" : "6Lfbwe0gAAAAANqUystO9dr455AWtvwCd3HKx7Js";
        private const string BaseApiUrl = "https://localhost";
        public const string GoogleCaptchaVerificationUrl = "https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}";
        
        public MainPage()
        {
            InitializeComponent();
        }

        private async void Button_OnClicked(object sender, EventArgs e)
        {
            IReCaptchaService reCaptchaService = Xamarin.Forms.DependencyService.Get<IReCaptchaService>();

            var captchaToken = await reCaptchaService.Verify(SiteKey, BaseApiUrl);
            
            if (captchaToken == null)
            {
                return;
            }
            
            var captchaVerificationUrl = string.Format(GoogleCaptchaVerificationUrl, SiteSecretKey, captchaToken);
            // TODO: POST to captchaVerificationUrl
        }
    }
}